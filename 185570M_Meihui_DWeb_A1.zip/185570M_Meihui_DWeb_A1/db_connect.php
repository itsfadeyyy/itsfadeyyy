<?php

$mysqli = new mysqli("localhost","root","","db_forum1");

?>