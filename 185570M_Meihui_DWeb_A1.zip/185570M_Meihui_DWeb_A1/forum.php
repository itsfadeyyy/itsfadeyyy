<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Forum</title>

  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">

  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/main.css">
  <link href="https://fonts.googleapis.com/css?family=Bitter&display=swap" rel="stylesheet">

  <meta name="theme-color" content="#fafafa">
	<meta name="viewport" content="width=device-width, initialscale=1">
	
	<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
	  <script src="js/vendor/modernizr-3.7.1.min.js"></script>
  <script>window.jQuery || document.write('<script src="js/vendor/jquery-3.4.1.min.js"><\/script>')</script>
  <script src="js/plugins.js"></script>
  <script src="js/main.js"></script>
</head>

<body>
	
	
	
</body>
</html>